# Sports Commentator

[TODO: 一句话描述]

## 类型

Agent 型（单个 AI 专家）

## 功能

[TODO: 详细功能说明]

## 使用示例

- [TODO: 示例提示词1]
- [TODO: 示例提示词2]
- [TODO: 示例提示词3]

## 头像

头像使用 ClawClaw 内置的 36 个预置头像。`plugin.json` 中的 `avatar` 为 0–35 的编号。

## 安装

将专家包目录放到专家目录下：

```
/Users/angusfan/.clawclaw/data/plugins/marketplaces/my-experts/plugins/sports-commentator/
```

然后运行注册命令使其可见：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
zip -r sports-commentator.zip sports-commentator/
```
