import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { NativeClientConfig, NativeChannel } from '@deepseek-ai/dsh-cua/native-client';
export type { NativeChannel } from '@deepseek-ai/dsh-cua/native-client';
/**
 * Prepare or join the native process; writes wait for identity-checked readiness.
 * @param owner - Provider owning the short-lived native startup command.
 * @param config - Native runtime identity, operation limits and connection deadlines.
 * @returns One independently disposable Agent connection, without operation replay.
 */
export declare function createSharedNativeChannel(owner: {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
}, config: NativeClientConfig): NativeChannel;
//# sourceMappingURL=shared-native.d.ts.map