/**
 * @deepseek-ai/dsh-harness-dev-context — model context for an agent that can
 * inspect and extend the DeepSeek Harness serving its Web GUI. It registers
 * path- and URL-free prompt sections and states the current implementation
 * checkout and Web GUI URL as runtime context, so a process started from
 * another checkout, port, or installation leaves the system prompt unchanged.
 * A Session whose admitted prompt holds the paragraphs that embedded those
 * values keeps them verbatim, so resuming it never rewrites its logged prompt.
 * @module @deepseek-ai/dsh-harness-dev-context
 */
import type { Context } from '@deepseek-ai/cordis';
import { z as zod } from 'zod';
/** Stable Cordis plugin name. */
export declare const name = "harness-dev-context";
/** Prompt registries, the projection registry, and the Web GUI whose URL the model learns. */
export declare const inject: string[];
declare const legacyPromptSchema: zod.ZodObject<{
    source: zod.ZodNullable<zod.ZodString>;
    web: zod.ZodNullable<zod.ZodString>;
}, zod.core.$strip>;
/** Value-bearing paragraphs of the latest nonempty system prompt a Session committed; `null` where it has none. */
type LegacyPrompt = zod.infer<typeof legacyPromptSchema>;
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionStateMap {
        /** Value-bearing harness-source and Web-surface paragraphs of the latest nonempty admitted system prompt. */
        harnessDevLegacyPrompt: LegacyPrompt;
    }
}
/**
 * Register the two sections, their runtime-context values, and the
 * projection that keeps a Session's admitted paragraphs.
 * @param ctx - plugin context with every {@link inject} service.
 */
export declare function apply(ctx: Context): void;
export {};
//# sourceMappingURL=index.d.ts.map