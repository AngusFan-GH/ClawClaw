/** Locale preference stored in the Host user-settings document. */
import z from '@deepseek-ai/schemastery';
/** Settings namespace owned by the locale plugin. */
export declare const LOCALE_SETTINGS_NAMESPACE = "locale";
/** Field carrying an explicit locale selection; absence delegates to the browser. */
export declare const LOCALE_PREFERENCE_FIELD = "preference";
/** Accepted BCP 47-style language ids. */
export declare const LOCALE_ID_PATTERN: RegExp;
/** Locale identifiers shipped by the browser client. */
export declare const LOCALE_IDS: readonly ["zh", "en"];
/** Locale identifier shipped by the browser client. */
export type BuiltInLocaleId = typeof LOCALE_IDS[number];
/** Open locale identifier accepted from language-pack plugins. */
export type LocaleId = string;
/** Durable locale section shared by the Host schema and the browser scope. */
export interface LocaleSettings {
    /** Explicit locale selection; absence delegates to the browser. */
    preference?: LocaleId;
}
/** Durable locale schema; also the wire envelope the browser scope validates against. */
export declare const LocaleSettingsFields: {
    preference: z<string, string, "plain">;
};
/** Schema for the shared locale preference. */
export declare const LocaleSettingsSchema: z<Schemastery.ObjectS<NoInfer<{
    preference: z<string, string, "plain">;
}>>, Schemastery.ObjectT<NoInfer<{
    preference: z<string, string, "plain">;
}>>, "plain">;
//# sourceMappingURL=locale-settings.d.ts.map